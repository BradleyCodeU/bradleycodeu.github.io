package io.github.bradleycodeu;
public class Stats {

  private int wins;
  private int losses;
  private int pointsScored;

  public Stats() {
    wins = 0;
    losses = 0;
    pointsScored = 0;
  }

  // addLoss() increments losses by 1

  // addPointsScored(int points) increments points

  // addWin() increments wins by 1

  // getWins()

  // getLosses()

  // toString
}