package io.github.bradleycodeu;
class U5aStudentApp {
  public static void main(String[] args) {
    Student demoStudent = new Student("x");
    demoStudent.addQuiz(99);
    demoStudent.addQuiz(98);
    demoStudent.addQuiz(98);
    System.out.println("Added the following quiz scores: 95, 65, 85");
    System.out.println("Expected Total = ");
    System.out.println("Expected Average = ");
    System.out.println("Actual results");
    System.out.println("Name = ");
    System.out.println("Id Number = ");
    System.out.println("Email = ");
    System.out.println("Total Score = ");
    System.out.println("Average Score = ");
  }
}