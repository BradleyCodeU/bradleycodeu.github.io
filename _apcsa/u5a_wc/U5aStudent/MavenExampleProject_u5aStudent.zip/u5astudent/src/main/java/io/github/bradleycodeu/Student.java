package io.github.bradleycodeu;

public class Student {
    private String name;
    private String email;
    private int id;
    private int totalQuizScore;
    private int numberOfQuizzes;

    public Student(String n) {
        name = n;
    }

    public void addQuiz(int score) {
        // NOTE: Adds score to the total quiz score AND adds 1 to the counter
        totalQuizScore += score;
    }

    public String getName() {
        return "name";
    }

    public int getIdNumber() {
        return -1;
    }

    public String getEmail() {
        return "email";
    }

    public int getTotalScore() {
        return totalQuizScore;
    }

    public double getAverageScore() {
        return 0;
    }
}
