package io.github.bradleycodeu;



public class U1aPaintCalcIntOnly {
  public static int calculateWallArea(int length, int width, int height, int num_doors, int num_windows)
  {
    // Calculate the total surface area of the walls
    return 0;
  }

  public static int calculatePaintGallons(int total_area)
  {
    // Calculate the number of gallons of paint needed
    // Assume that 1 gallon can of paint will cover 400 square feet PLUS always buy 1 extra
    // For example, calculatePaintGallons(432) --> 2.
    return 0;
  }

  public static int calculateCostEstimate(int gallons_needed, int price_per_gallon, int sales_tax_percent)
  {
    // Calculate the total cost including sales tax PLUS 1
    return 0;
  }


  public static void main(String[] args) {
    // Declare all variables here

    System.out.println("Enter the room dimensions below");
    System.out.print("Length: ");
    System.out.print("Width: ");
    System.out.print("Height: ");
    System.out.print("How many doors does the room have: ");
    System.out.print("How many windows does the room have: ");
    System.out.print("Enter the price of a gallon of paint: ");
    System.out.print("Enter the sales tax percent: ");

    // Use the methods to calculate the results
    // calculateWallArea(int length, int width, int height, int num_doors, int num_windows)
    // calculatePaintGallons(int total_area)
    // calculateCostEstimate(int gallons_needed, int price_per_gallon, int sales_tax_percent)

    System.out.println("Results");
    System.out.println("Total square feet = ");
    System.out.println("Gallons of paint needed = ");
    System.out.println("Cost estimate = ");



  }
}