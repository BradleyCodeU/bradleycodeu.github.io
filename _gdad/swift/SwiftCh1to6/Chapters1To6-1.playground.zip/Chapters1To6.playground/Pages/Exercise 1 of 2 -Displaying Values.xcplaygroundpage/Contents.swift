
/*:
 ## Exercise 1 of 2: Displaying Values
 
 You may recall from an earlier playground an exercise that involved calculating the space remaining on an iPhone. You had the following information:
 
 - The capacity of an iPhone is measured in gigabytes (GB). The iPhone in question has 8GB of storage.
 - A gigabyte is about 1,000 megabytes (MB)
 - The phone already has 3GB of stuff on it
 - One minute of video takes 150MB of space
 
 - callout(Exercise): Create variables and/or constants for ALL of the information in the above prompt. Create a string that tells the user how many minutes of video they can store on the phone. You'll first need to perform the calculation steps, then use string interpolation to display the answer - which should look like this:
 
 `You can record XXX more minutes of video.`
 
 _Remember:_ Your calculations should NOT have any magic numbers (number literals). For example, `storageCapacityMb = 8 * 1000` contains TWO magic numbers. Yuck.
 
 Instead...
 
-   declare a constant named storageCapacityGb and assign the value 8
-   declare a constant named mbPerGb so that you can do all of your calculations in megabytes.
-   calculate storageCapacityMb = storageCapacityGb \* mbPerGb. Nice and readable!
 
 */







//:[Previous](@previous)  |   [Next](@next)
