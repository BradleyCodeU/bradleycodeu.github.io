/*:
 ## Exercise 2 of 3: Leap Years
 
 To decide if a year is a leap year, there are several decisions that have to be made:
 
 - Is the year divisible by 4?
    - If so, is the year divisible by 100?
        - If not, it is a leap year.
        - If so, is the year divisible by 400?
            - If not, it is **not** a leap year.
            - If so, it is a leap year.
 
 These decisions can be made inside a function. Below is an incomplete function for deciding if a given year is a leap year:
*/
func isLeapYear(_ year: Int) -> Bool {
    if year % 4 == 0 {
        // Fill in this code...
        return true
    } else {
        return false
    }
}
// Should be true
isLeapYear(2000)
// Should be false
isLeapYear(1900)
// Should be true
isLeapYear(2012)
// Should be false
isLeapYear(2017)
// Should be true
isLeapYear(2400)
//: - callout(Exercise): Complete the function above so that the rules are all followed and the examples get the correct answers.

//: [Previous](@previous)  |  [Next](@next)
