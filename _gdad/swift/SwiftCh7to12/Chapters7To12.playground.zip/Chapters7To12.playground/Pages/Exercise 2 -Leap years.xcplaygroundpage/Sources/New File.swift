public func number(_ number: Int, isDivisibleBy divisor: Int) -> Bool {
    return number % divisor == 0
}

